LoonBestInSlot.ItemSources = 
{
    {12345,--id
    "Name ?? Dunno if i want this here", --Name of item.  Can also be queried in game.
    "Slot ?? Dunno if i want this here.", --Head, Shoulders, Back, Chest, Bracers, Gloves, Belt, Legs, Feet, Neck, Ring, Trinket, 2H, MH, OH, Shield, Ranged, Totem, Libram, Idol 
    "Drop",--SourceType: Drop/Token, Profession, PvP, Honor Token, Reputation, Quest
    "Source",--Source: MobName, ProfessionName, PvP Points, Tokens, Reputation (Level)
    "SourceLocation"--SourceLocation: RaidName, QuestZone
    },


}

